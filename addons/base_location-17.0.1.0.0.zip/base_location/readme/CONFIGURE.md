1.  Go to *Contacts / Configuration / Localization / Cities*.
2.  Create a new City.
3.  Go to *Contacts / Configuration / Localization / Zips*.
4.  Create a new Zip and relate it to the city (you can also create the
    Zip from the City).

or, with module 'Contacts Directory' installed: \#. Go to *Contacts /
Configuration / Localization / Countries*. \#. Locate the desired
country. \#. Press on the button 'Cities' / 'Zips'.
